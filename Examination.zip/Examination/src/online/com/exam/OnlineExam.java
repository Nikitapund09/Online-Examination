package online.com.exam;

	import java.awt.event.ActionEvent;
	import java.awt.event.ActionListener;
	import javax.swing.ButtonGroup;
	import javax.swing.JButton;
	import javax.swing.JFrame;
	import javax.swing.JLabel;
	import javax.swing.JOptionPane;
	import javax.swing.JRadioButton;


	class OnlineExam extends JFrame implements ActionListener {
			
		private static final long serialVersionUID = 1L;

			JLabel label;
			JRadioButton radioButton[] = new JRadioButton[5];
			JButton btnNext, btnBookmark;
			ButtonGroup bg;
			int count = 0, current = 0, x = 1, y = 1, now = 0;
			int m[] = new int[10];

			// create jFrame with radioButton and JButton
			OnlineExam(String s)
			{
				super(s);
				label = new JLabel();
				add(label);
				bg = new ButtonGroup();
				for (int i = 0; i < 5; i++)
				{
					radioButton[i] = new JRadioButton();
					add(radioButton[i]);
					bg.add(radioButton[i]);
				}
				btnNext = new JButton("Next");
				btnBookmark = new JButton("Bookmark");
				btnNext.addActionListener(this);
				btnBookmark.addActionListener(this);
				add(btnNext);
				add(btnBookmark);
				set();
				label.setBounds(30, 40, 450, 20);
				//radioButton[0].setBounds(50, 80, 200, 20);
				radioButton[0].setBounds(50, 80, 450, 20);
				radioButton[1].setBounds(50, 110, 200, 20);
				radioButton[2].setBounds(50, 140, 200, 20);
				radioButton[3].setBounds(50, 170, 200, 20);
				btnNext.setBounds(100, 240, 100, 30);
				btnBookmark.setBounds(270, 240, 100, 30);
				setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				setLayout(null);
				setLocation(250, 100);
				setVisible(true);
				setSize(600, 350);
			}

			
			public void actionPerformed(ActionEvent e) 
			{
				if (e.getSource() == btnNext)
				{
					if (check())
						count = count + 1;
					current++;
					set();
					if (current == 9)
					{
						btnNext.setEnabled(false);
						btnBookmark.setText("Result");
					}
				}
				if (e.getActionCommand().equals("Bookmark"))
				{
					JButton bk = new JButton("Bookmark" + x);
					bk.setBounds(480, 20 + 30 * x, 100, 30);
					add(bk);
					bk.addActionListener(this);
					m[x] = current;
					x++;
					current++;
					set();
					if (current == 9)
						btnBookmark.setText("Result");
					setVisible(false);
					setVisible(true);
				}
				for (int i = 0, y = 1; i < x; i++, y++) {
					if (e.getActionCommand().equals("Bookmark" + y)) 
					{
						if (check())
							count = count + 1;
						now = current;
						current = m[y];
						set();
						((JButton) e.getSource()).setEnabled(false);
						current = now;
					}
				}

				if (e.getActionCommand().equals("Result"))
				{
					if (check())
						count = count + 1;
					current++;
					JOptionPane.showMessageDialog(this, "correct answers= " + count);
					System.exit(0);
				}
			}

			
			void set() {
				radioButton[4].setSelected(true);
				if (current == 0)
				{
					label.setText("Que1:  Which is the extension of java code file?");
					radioButton[0].setText(".file");
					radioButton[1].setText(".java");
					radioButton[2].setText(".program");
					radioButton[3].setText(".code");
				}
				if (current == 1) 
				{
					label.setText("Que2:  JRE stands for");
					radioButton[0].setText("java runtime ecosystem");
					radioButton[1].setText("java runtime environment");
					radioButton[2].setText("java run envirement");
					radioButton[3].setText("none");
				}
				if (current == 2) 
				{
					label.setText("Que3: What is the entry point of a program in java?");
					radioButton[0].setText("main()method");
					radioButton[1].setText("The first line code");
					radioButton[2].setText("Tain class");
					radioButton[3].setText("None");
				}
				if (current == 3) 
				{
					label.setText("Que4: Which of the following method are present in comparator interface ?");
					radioButton[0].setText("String");
					radioButton[1].setText("foreach ");
					radioButton[2].setText("compare");
					radioButton[3].setText("List");
				}
				if (current == 4) 
				{
					label.setText("Que5:  Object in java are ----.");
					radioButton[0].setText(" References");
					radioButton[1].setText("Class");
					radioButton[2].setText("Inscript");
					radioButton[3].setText("Narcissus");
				}
				if (current == 5) {
					label.setText("Que6: -----is used to find and fix bugs in the java programs?");
					radioButton[0].setText("JDB");
					radioButton[1].setText("JDK");
					radioButton[2].setText("JRE");
					radioButton[3].setText("JVM");
				}
				if (current == 6)
				{
					label.setText("Que7:  Which keyword  is used to inherit classes in java ?");
					radioButton[0].setText("Catch ");
					radioButton[1].setText("Extends");
					radioButton[2].setText("Auto");
					radioButton[3].setText("Streams");
				}
				if (current == 7) 
				{
					label.setText("Que8:  Empty interface in java is called ?");
					radioButton[0].setText("Derived class");
					radioButton[1].setText("Abstract class");
					radioButton[2].setText("Marker interface");
					radioButton[3].setText("None");
				}
				if (current == 8) 
				{
					label.setText("Que9: Which java method is used to clear element of ArrayList ?");
					radioButton[0].setText("Clear()");
					radioButton[1].setText("Delete()");
					radioButton[2].setText("Delete all()");
					radioButton[3].setText("None");
				}
				if (current == 9) 
				{
					label.setText("Que10: What is the full form of AWT ?");
					radioButton[0].setText("Absolute window toolkit");
					radioButton[1].setText("Abstract window toolkit");
					radioButton[2].setText("Absolute window tool");
					radioButton[3].setText("Absolute wear toolkit");
				}
				label.setBounds(30, 40, 450, 20);
				for (int i = 0, j = 0; i <= 90; i += 30, j++)
					radioButton[j].setBounds(50, 80 + i, 200, 20);
			}

			// declare right answers.
			boolean check() {
				if (current == 0)
					return (radioButton[1].isSelected());
				if (current == 1)
					return (radioButton[1].isSelected());
				if (current == 2)
					return (radioButton[0].isSelected());
				if (current == 3)
					return (radioButton[2].isSelected());
				if (current == 4)
					return (radioButton[0].isSelected());
				if (current == 5)
					return (radioButton[0].isSelected());
				if (current == 6)
					return (radioButton[1].isSelected());
				if (current == 7)
					return (radioButton[2].isSelected());
				if (current == 8)
					return (radioButton[0].isSelected());
				if (current == 9)
					return (radioButton[0].isSelected());
				return false;
			}

			public static void main(String s[]) {
				new OnlineExam("Online Test App");
			}

		}

		
		
		


	


